
def change_datge_format(date):
    result=""
    for i in date.split("/",3)[::-1]:
        result+=i+"/"
    return result[:-1]

