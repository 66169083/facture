from ttkbootstrap import *
from ttkbootstrap.constants import *

from time import strftime
from tkinter import filedialog

from os import startfile
from ttkbootstrap.dialogs import Messagebox as messagebox
from logique import *


root = Window(themename="litera")
root.geometry("1300x650+10+10")
font = "Bookman Old Style"
root.iconbitmap("logo.ico")
root.title("Logiciel de gestion de dévis")

colonnes_materiel_table = ["Références", "Unité", "Quantité", "Prix Unitaire", "Montant Total"]
list_width_mat_table = [80, 120, 220, 230]
list_colonnes = ["reference", "unite", "qte", "prix_unitaire", "montant_ht"]
facture_table_colonnes = ["Client", "N°Facture", "Date", "Matériels", "Main d'œuvre",
                          "Total", "Reste"]
list_anchor_coloums = ["nw", "n", "n", "center", "center", "center", "center"]
list_colonnes_width = [200, 170, 110, 130, 155, 160, 100]
consulter_facture_colonnes = ["client_name", "facture_number", "Date",
                              "Montant_achat_materiels", "Montant_Main_oeuvre", "Montant_Total", "Reste"]

colonne_bilan = ["Client", "N°Facture", "Date", "Matériel", "Main d'œuvre","Total", "Reste", ]

#frames

list_string_var = [StringVar() for _ in range(10)]
frame_window = Frame(root, width=1100, height=630, relief="raised")
frame_window.place(relx=0.14, rely=0.001)
frame_menu = Frame(root, width=180, height=400, relief="groove")
frame_menu.place(relx=0.001, rely=0.07)
frame_info_client = Frame(frame_window, width=1046, height=596)

frame_remplissage_materiel = Frame(frame_window, width=1046, height=620)
frame_modifier_reste_payer = Frame(frame_window, width=1046, height=620)
frame_last_part = Frame(frame_window, width=1046, height=596)

frame_consulter_facture = Frame(frame_window, width=1046, height=596)

frame_page_accueil = Frame(frame_window, width=1098, height=596)
frame_page_accueil.place(relx=0.001,rely=0.001)
frame_bilan = Frame(frame_window, width=1046, height=596)

frame_parametres = Frame(frame_window, width=1046, height=596)

frame_resume_facture= Frame(frame_window, width=1095, height=596)

list_frames = [frame_bilan,frame_page_accueil,frame_resume_facture,frame_modifier_reste_payer,
frame_info_client,frame_remplissage_materiel,frame_last_part,frame_consulter_facture,
               frame_parametres]

def resize_image(image, width, height):
    image_resize = Image.open(image).resize((width, height))
    return ImageTk.PhotoImage(image_resize)

image_faire_facture=resize_image("invoice.png",320,350)
image_consult_fact=resize_image("consult_fact.png",320,350)
image_faire_bilan=resize_image("bilan_fact.png",270,350)
image_menu_bar=resize_image("list.png",30,30)


def show_widget(widget: Frame, x=0.001, y=0.001):
    for frame in list_frames:
        frame.place_forget()
    widget.place(relx=x, rely=y)
    
def set_dark_theme():
    if string_var_mode_sombre.get():
        root.style.theme_use("darkly")
        style_buttons_menu.configure("success.TButton", font=(font, 14))
        style_list_buttons_cons.configure("Custom2.success.TButton", font=(font, 13))
        style_button_suivant.configure("Suivant.success.TButton", font=(font, 16))
        style.configure("Treeview.Heading", font=("Bookman Old Style", 15, "bold"),
                        borderwidth=1, )
        style.configure("Treeview",
                        font=("Helvetica", 15,), borderwidth=2, rowheight=30)
        style_button_accueil.configure("Accueil.success.TButton",font=(font,17))
        Style().configure("Parametre.danger.TButton", font=(font, 16))

    else:
        root.style.theme_use("litera")

class Resume(Frame):
    def __init__(self, master, nom_client, numero_client,
        adresse_client,nom_facture, date,items, total_achat, main_oeuvre,
         main_oeuvre_descript,   total, avance, reste,):


        super().__init__(master,)
        self.avance=avance
        self.nom_client=nom_client
        self.adresse=adresse_client
        self.numero_client=numero_client
        self.reste=reste
        self.total=total
        self.items=loads(items)
        self.total_achat=total_achat
        self.main_oeuvre=main_oeuvre
        self.main_oeuvre_descript=main_oeuvre_descript
        self.date=date
        self.nom_facture=nom_facture
        list_width_mat_table=[200,60,150,200,200]

    def show_window(self):
        self.configure(width=1100,height=650)
        self.place(relx=0.001,rely=0.001)
        frame_resume_facture=self
        """#frame_resume_facture=Frame(self,width=1200,height=650)
        frame_resume_facture.place(relx=0.001,rely=0.001)"""
        frame1=Frame(frame_resume_facture,width=1100,height=250)
        frame1.place(relx=0.001,rely=0.075)


        Label(frame_resume_facture, text="Résumé de la Facture",style="success"
              , font=(font, 22, "bold", "italic"), ).place(relx=0.3, rely=0.01)
        label_date_resume=Label(frame1,text="Date:"+self.date,font=(font,19))
        label_date_resume.place(relx=0.05,rely=0.81)
        label_nom_client=Label(frame1,text="Nom: "+self.nom_client,font=(font,19))
        label_nom_client.place(relx=0.05,rely=0.04)
        label_client_num=Label(frame1,text="Tel: "+self.numero_client,font=(font,19))
        label_client_num.place(relx=0.05,rely=0.212)
        label_client_address=Label(frame1,text="Adresse :"+self.adresse,font=(font,19))
        label_client_address.place(relx=0.05,rely=0.38)
        label_nom_facture=Label(frame1,text=self.nom_facture,font=(font,19))
        label_nom_facture.place(relx=0.05,rely=0.55)

        label_achat_materiel=Label(frame1,text="Total achat Matériel:"+self.total_achat,font=(font,15,"bold"))
        label_achat_materiel.place(relx=0.62,rely=0.05)

        label_main_oeuvre=Label(frame1,text="Main d'œuvre: "+self.main_oeuvre,font=(font,17,"bold"))
        label_main_oeuvre.place(relx=0.66,rely=0.22)

        label_main_oeuvre_des=Label(frame1,text=self.main_oeuvre_descript,font=(font,19))
        label_main_oeuvre_des.place(relx=0.05,rely=0.68)

        label_avance_resume=Label(frame1,text="Avance : "+self.avance,font=(font,19))
        label_avance_resume.place(relx=0.66,rely=0.39)

        label_reste_resume=Label(frame1,text="Reste : "+self.reste,font=(font,19))
        label_reste_resume.place(relx=0.66,rely=0.59)

        label_total_resume=Label(frame1,text="Total : "+self.total,font=(font,20,"bold"))
        label_total_resume.place(relx=0.66,rely=0.75)
        frame_table_resume=Frame(self,width=900,height=230,relief="raised")
        frame_table_resume.place(relx=0.05,rely=0.45)

        table_resume = ttk.Treeview(frame_table_resume, columns=colonnes_materiel_table, show="headings", height=7)
        scrollbar = Scrollbar(frame_table_resume, orient="vertical", command=table_resume.yview)
        scrollbar.pack(fill="y", side="right")

        table_resume.pack(fill="both")
        table_resume.configure(yscrollcommand=scrollbar.set)
        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Bookman Old Style", 14, "bold"),
                        borderwidth=1, row_border=1)


        for colonne in colonnes_materiel_table:
            table_resume.heading(colonne, text=colonne)
        for i, colonne in enumerate(colonnes_materiel_table[1:]):
            table_resume.column(colonne, width=list_width_mat_table[i], anchor="n")

        for ind,materiel  in enumerate(self.items):
            table_resume.insert(parent="",index=0,values=list(materiel.values()))
        table_resume.column("Références", width=360)
        table_resume.tag_configure("oddrow", background="lightblue")
        table_resume.tag_configure("evenrow", background="white")

        style=t=Style()
        style.configure("Custom1.success.TButton",font=(font,15))
        button_faire_facture = Button(frame_resume_facture, style="Custom1.success.TButton",
                        text="Enregistrer Facture",width=16,command=valider)
        button_faire_facture.place(relx=0.45,rely=0.85)

        button_retour = Button(frame_resume_facture, style="Custom1.success.TButton",
                                      text="Retour", width=8,command=show_frame_last_part )
        button_retour.place(relx=0.1, rely=0.87)


def get_save_directory():
    path = filedialog.askdirectory()
    directory_to_save_facture.configure(text=str(path))
def refresh_materiel_number():
    materiel_number = len(get_table_values()) + 1
    materiel_number_label.configure(text="Matériel N° " + str(materiel_number))
    root.after(100, refresh_materiel_number)
def show_frame_faire_facture():
    list_string_var[4].set(get_date())
    show_widget(frame_info_client)

def show_parametres():
    show_widget(frame_parametres)

def get_date():
    return strftime("%d/%m/%Y")
def show_frame_last_part():
    show_widget(frame_last_part, x=0.001, y=0.05)
def show_frame_accueil():
    show_widget(frame_page_accueil)
def retour_last_part_to_remplissage_mat():
    show_widget(frame_remplissage_materiel)
def show_frame_remplissage_materiel():
    if not nom_client.get().strip() or not nom_facture.get().strip():
        client_name_pop_up = messagebox.show_error(title="Erreurs détectées",
        position=(600,250),message="Veuillez entrer le nom du client et \n le nom de la facture")
    else:
        stringVar_list[1].set("U")
        stringVar_list[2].set("1")
        show_widget(frame_remplissage_materiel, x=0, y=0.001)


def consulter_facture():
    show_widget(frame_consulter_facture)
def faire_bilan():
    show_widget(frame_bilan)

def show_acceuil():
    show_widget(frame_page_accueil)

def clear_all_entries():
    nom_client.delete(0, END)
    numero_client.delete(0, END)
    nom_facture.delete(0, END)
    avance_entry.delete(0, END)
    reste_payer.delete(0, END)
    montant_total_label.configure(text="")
    main_oeuvre.delete(0, END)
    main_oeuvre_descipt.delete(0, END)
    adresse_client.delete(0, END)
    numero_client.delete(0, END)
    Quantite.delete(0, END)
    prix_Total.delete(0, END)
    prix_unitaire.delete(0, END)
    Unite.delete(0, END)
    nom_materiel.delete(0, END)
    for element in treeview_achat_materiel.get_children():
        treeview_achat_materiel.delete(element)

def set_montant_total_materiel():
    quantite = Quantite.get()
    prix_unit = prix_unitaire.get()
    try:
        string_var_total.set(set_espace_between_3_numbers(str(int(quantite) * int(prix_unit))))
    except:
        pass
    frame_remplissage_materiel.after(100, set_montant_total_materiel)
def afficher_resume_facture():
    avance = avance_entry.get()
    gere_montant = gerer_montant(delete_space_3numbers(main_oeuvre.get()))
    gerer_avance = gerer_montant(delete_space_3numbers(avance))
    total = delete_space_3numbers(montant_total_label.cget("text"))
    state_avance_reste = gerer_montant_total_avance_reste(delete_space_3numbers(avance), total)
    gerer_montant_descript = gerer_montant_oeuvre_and_description(delete_space_3numbers(main_oeuvre.get()),
                                                                  main_oeuvre_descipt.get())
    data = get_all_datas("tableau")[1:-3]
    status_main_oeuvre = True
    if main_oeuvre.get().strip():
        status_main_oeuvre = False
        try:
            float(delete_space_3numbers(main_oeuvre.get()))
            status_main_oeuvre = True
        except:
            pass
    if state_avance_reste[0]:
        if status_main_oeuvre:
            if gerer_montant_descript:

                if delete_space_3numbers(total.strip()) == "0":
                    messagebox.show_error(title="Status de la Facture",position=(700,260),
                    message="la facture est vide \n remplissez la d'abord")
                else:
                    show_widget(frame_resume_facture)
                    resume = Resume(frame_resume_facture, *data)
                    resume.show_window()
            else:
                messagebox.show_error(title="Description de la main d'œuvre",position=(700,260),
                    message="Veuillez remplir la description\n de la main d'œuvre et \n le Montant de la main d'œuvre")
        else:
            messagebox.show_error(position=(700,260),title="Main d'œuvre", message="Montant  de la main d'œuvre \n est invalide")
    else:
        messagebox.show_error(position=(850,330),title="Erreurs détectées", message=state_avance_reste[1])
def valider(type="enregistrer", id_facture=""):
    data = get_all_datas("facture")
    if type == "enregistrer":
        status1 = messagebox.okcancel(position=(600,250),title="Sauvegarder la facture", message="Voulez-vous \n enregistrer cette facture ?")
        if status1:
            insert_facture(data)
            status = messagebox.okcancel(position=(600,250),title="", message="Voulez vous exporter en PDF ?")
            if status:
                get_save_directory()
                path = directory_to_save_facture.cget("text")
                data=list(data[:-3])

                data[4]=cut_string(main_oeuvre_descipt.get(),86)
                facture = Facture(*tuple(data), path)
                numero_facture = "Facture Proforma " + (facture.numero_facture).replace("/", "_") + ".pdf"
                facture.produire_facture()
                clear_all_entries()
                messagebox.show_info(position=(600,200),message="Facture enregistrée avec succès")
                status2 = messagebox.yesno(position=(600,200),title="Ouverture de la Facture", message="Voulez-vous ouvrir la facture?")
                if status2:
                    startfile(path + "/" + numero_facture, operation="open")

    else:
        status1 = messagebox.yesno(position=(750,300),title="Sauvegarde la facture", message="Confirmez-vous la \nmodification cette facture ?")
        if status1:
            update_facture_data(id_facture, data[1:])
            messagebox.show_info(position=(500,260),title="Status de la modification", message="Facture modifiée\navec succès")
def test():
    afficher_resume_facture()
def test1():
    if get_selected_facture():
        id_facture = list_facture_table.item(get_selected_facture()[0])["values"][1]

        valider("modification", id_facture=id_facture)
    else:
        valider()
def modifier_completement_facture():
    selection = get_selected_facture()[0]
    button_valider.configure(command=test1)
    id_facture = list_facture_table.item(selection)["values"][1]
    values, items = get_value_for_modification(id_facture)
    items = loads(items)
    for index, value in enumerate(values):
        list_string_var[index].set(value)
    for childreen in treeview_achat_materiel.get_children():
        treeview_achat_materiel.delete(childreen)
    for item in items:
        treeview_achat_materiel.insert("", index=0, values=tuple(item.values()))
    show_widget(frame_info_client, x=0.001, y=0.001)

def get_all_datas(type):
    avance = set_espace_between_3_numbers(avance_entry.get())
    reste = set_espace_between_3_numbers(reste_payer.get())
    main_oeuvre_name = main_oeuvre_descipt.get()
    main_oeuvre_montant = set_espace_between_3_numbers(main_oeuvre.get().strip())
    client_name = nom_client.get()
    client_number = numero_client.get()
    client_address = adresse_client.get()
    facture_name = nom_facture.get()
    Date = date.entry.get()
    if type == "facture":
        main_oeuvre_name = cut_string(main_oeuvre_name, 84)
        client_address = cut_string(client_address, 60)
        facture_name = cut_string(facture_name, 90)
        client_name=cut_string(client_name,60)
    else:
        client_name=cut_string(client_name,40)
        client_number=cut_string(client_number,34)
        client_address=cut_string(client_address,30)
        main_oeuvre_name = cut_string(main_oeuvre_name, 45)
        facture_name = cut_string(facture_name, 45)
    items = dumps(get_table_values())
    numero_facture = generer_numero_facture(*get_mois_jour(Date)[1:], "/")
    total_materiel = set_espace_between_3_numbers(calcul_montant_total_materiels())
    Total = set_espace_between_3_numbers(calcul_montant_total())
    jour, mois, annee = get_mois_jour(Date)

    if not main_oeuvre_montant:
        main_oeuvre_montant = "0"
    return (numero_facture, client_name, client_number, client_address,
            facture_name, Date, items, total_materiel, main_oeuvre_montant, main_oeuvre_name,
            Total, avance, reste, jour, mois, annee)


def calcul_montant_total():
    try:
        main_oeuvre_montant = int(delete_space_3numbers(main_oeuvre.get()))
        return str(main_oeuvre_montant + int(delete_space_3numbers(str(calcul_montant_total_materiels()))))
    except:
        return calcul_montant_total_materiels()


def get_materiel_values():
    material_name = nom_materiel.get()
    quantity = Quantite.get()
    prix_unit = prix_unitaire.get()
    unite = Unite.get()
    prix_Tot = prix_Total.get()
    return (material_name, unite, quantity, prix_unit, prix_Tot)
def get_table_values():
    resultat = []
    values = []
    for element in treeview_achat_materiel.get_children():
        values.append(treeview_achat_materiel.item(element)["values"])
    for value in values:
        value[0] = cut_string(value[0], 60)
        resultat.append({list_colonnes[index]: value[index] for index in range(5)})
    return resultat
def set_montant_total_facture():
    main_oeuvre_montant = delete_space_3numbers(main_oeuvre.get())
    total_montant_materiel = calcul_montant_total_materiels()
    text = set_espace_between_3_numbers(calcul_montant_total_materiels())
    try:
        text = str(set_espace_between_3_numbers(int(total_montant_materiel) + int(main_oeuvre_montant)))
    except:
        pass
    montant_total_label.configure(text=text)
    root.after(100, set_montant_total_facture)
def set_montant_restant():
    montant_total = montant_total_label.cget("text")
    avance = avance_entry.get()
    try:
        text = float(delete_space_3numbers(montant_total)) - float(delete_space_3numbers(avance))
        if int(text) == text:
            text = int(text)
        string_var_rest.set(value=set_espace_between_3_numbers(text))
    except:
        pass
    root.after(100, set_montant_restant)
def calcul_montant_total_materiels():
    values = get_table_values()
    total = 0
    for materiel in values:
        total += float(delete_space_3numbers(materiel["montant_ht"]))
    if int(total) == total:
        total = int(total)
    return total
def supprimer_materiel():
    try:
        treeview_achat_materiel.delete(get_selected_element()[0])
    except:
        messagebox.show_error(position=(400,250),title="Erreurs",message= "Sélectionner un article puis \n" + "cliquez sur Supprimer")
def get_selected_element(*args):
    return treeview_achat_materiel.selection()


def ajouter_materiel(*args):
    status = gerer_materiel_descrip_montant_total(nom_materiel.get(), delete_space_3numbers(prix_Total.get()))
    if not status[0]:
        messagebox.show_error(position=(700,250),title="Erreurs",message=status[1])

    elif not gerer_montant(delete_space_3numbers(Quantite.get())):
        messagebox.show_error(position=(700, 250), title="Erreurs", message="Quantité doit être un entier")

    elif not gerer_montant(delete_space_3numbers(prix_unitaire.get())):
        messagebox.show_error(position=(700, 250), title="Erreusr", message='Le Prix unitaire est incorrect')
    elif not gerer_montant(delete_space_3numbers(prix_Total.get())):
        messagebox.show_error(position=(700, 250), title="Erreurs", message='Le Prix Total est incorrect')
    else:
        values = get_materiel_values()
        treeview_achat_materiel.insert(parent="", index=0, values=values)
        nom_materiel.delete(0,END)
        prix_unitaire.delete(0,END)
        prix_Total.delete(0, END)


def show_montant_total_materiel():
    try:
        text = calcul_montant_total_materiels()
        montant_total_materiel_label.configure(text=set_espace_between_3_numbers(text))
        montant_total_materiel_label1.configure(text=set_espace_between_3_numbers(text))
    except:
        pass
    root.after(100, show_montant_total_materiel)


def modifier_materiel():

    selected_element = get_selected_element()

    try:
        values=treeview_achat_materiel.item(selected_element[0])["values"][:-1]
        for index,element in enumerate(values):
            stringVar_list[index].set(element)
        treeview_achat_materiel.delete(selected_element[0])
    except:
        messagebox.show_error(position=(750,220),title="Erreur", message="Sélectionner un article puis \n" + "cliquez sur Modifier")


def set_frame_list_button():
    selection = ""
    try:
        selection = get_selected_element()[0]
    except:
        pass
    if selection:
        button_supprimer_materiel.place(relx=0.1, rely=0.4)
        button_modifier_materiel.place(relx=0.1, rely=0.1)
    else:
        button_supprimer_materiel.place(relx=1, rely=0.5)
        button_modifier_materiel.place(relx=1, rely=0.1)

    root.after(100, set_frame_list_button)
def show_all_facture():
    values = get_all_database_facture()
    for children in list_facture_table.get_children():
        list_facture_table.delete(children)
    for indexe, value in enumerate(values):
        tag = "evenrow" if indexe % 2 == 0 else "oddrow"
        list_facture_table.insert("", index=indexe, values=value)
def exporter_fichier():
    get_exporter_path()
    path = label_exporter_fichier.cget("text")
    element = get_selected_treeview_element()
    id_facture = list_facture_table.item(element[0])["values"][1]
    data = facture_data(id_facture)
    document = Facture(*data[:-3], path)
    document.produire_facture()
    messagebox.show_info(position=(600,140),title="Exportation de la facture", message="Exporter avec succès")
def chercher_facture(*args):
    for element in list_facture_table.get_children():
        list_facture_table.delete(element)
    Date = date
    numero_facture = numero_facture_entry.get()
    values = get_facture_with_id(numero_facture)
    if values:
        list_facture_table.insert("", 0, values=values)
    else:
        messagebox.show_info(position=(720,100),title="Status de la Recherche de la facture", message="Aucune Facture enregistrée ")
def supprimer_fichier():
    element = get_selected_treeview_element()
    id_facture = list_facture_table.item(element[0])["values"][1]
    resultat_supprimer = messagebox.yesno(title="Suppression de  la Facture",position=(850,180),
                message="être vous sûr de vouloir \nsupprimer cette facture ?")
    if resultat_supprimer:
        list_facture_table.delete(element[0])
        supprimer_facture(id_facture)
def get_selected_facture(*args):
    return list_facture_table.selection()
def get_exporter_path():
    path = filedialog.askdirectory()
    label_exporter_fichier.configure(text=path)
def modifier_reste_seul():
    montant_entree = delete_space_3numbers(entry_Regler.get())
    status = gerer_montant(montant_entree)
    if status:
        id_facture = list_facture_table.item(get_selected_facture()[0])["values"][1]
        reste = float(delete_space_3numbers(get_reste(id_facture)))
        if gerer_reglement_reste_payer(reste, float(montant_entree)):
            status1 = messagebox.okcancel(position=(300,300),title="status de la modification du reste à payer",
                                          message="Confirmez-vous  cette modification ?")
            if status1:
                update_reste(id_facture, float(montant_entree))
                entry_Regler.delete(0, END)
                messagebox.show_info(title="Reste à payer modifier", message="Modification éffectuée avec succès",
                                     position=(300,300))
        else:
            messagebox.show_error(position=(400,200),message="Montant à régler doit inférieur\n à" + str(reste))
    else:

        messagebox.show_error(position=(400,200),title="modification", message=" Le montant entré est invalide")
def set_modifier_reste(*args):
    selection = get_selected_facture()
    if selection:
        reste = (get_reste(list_facture_table.item(selection[0])["values"][1]))
        database_reste.configure(text=set_espace_between_3_numbers(reste))
        try:
            montant_entree = gerer_float_numbre(delete_space_3numbers(entry_Regler.get()))

            reste1 = float(delete_space_3numbers(reste.strip()))
            Resultat_reste.configure(
                text=set_espace_between_3_numbers(calcul_difference(reste1, float(montant_entree))).strip())
        except:

            Resultat_reste.configure(text=set_espace_between_3_numbers(reste))
    root.after(100, set_modifier_reste)
def modifier_reste():
    show_widget(frame_modifier_reste_payer)
def pack_list_consulter_button_mod_supp_exp():
    if get_selected_facture():
        frame_list_button_consult.place(relx=0.78, y=0.01)
    else:
        frame_list_button_consult.place(relx=1.2, y=0.01)

    root.after(100, pack_list_consulter_button_mod_supp_exp)
def fill_entry_regler():
    id_facture = list_facture_table.item(get_selected_facture()[0])["values"][1]
    reste = (delete_space_3numbers(get_reste(id_facture)))
    if checkbox:
        modifier_reste_stringvar.set(reste)
    else:
        modifier_reste_stringvar.set("")

def exporter_bilan():
    Date1, Date2 = label_date1_bilan.cget("text"), label_date2_bilan.cget("text")
    all_data = []
    if checkbox_bilan:
        all_data = get_all_database_data()
        Date1, Date2 = "", ""
    else:
        all_data = get_bilan(Date1, Date2)

    list_factures, totaux = calcul_totaux_bilan(all_data, Date1, Date2)

    if not list_factures:
        messagebox.show_info(position=(400,220),title="Status du Bilan",message= "désolé aucune facture enregistrée au cours\n de " +
                            str(Date1) + "  au  " + str(Date2))
    else:
        get_exporter_bilan_path()
        save_directory_path = exporter_bilan_path.cget("text")
        if save_directory_path:
            document = Bilan(list_factures, Date1, Date2, save_directory_path, *totaux)
            document.faire_PDF()
            messagebox.show_info(position=(700,320),title="Status du Bilan", message="Bilan Exporté\n avec succès")
def get_exporter_bilan_path():
    path = filedialog.askdirectory()
    exporter_bilan_path.configure(text=path)

def refresh_bilan_treeview(*args):
    set_bilan_treeview()
def call_checbox_bilan_fonction():
    if stringvar_bilan_checkbox.get():
        set_all_facture_treeview()
    else:
        for children in bilan_treewiew.get_children():
            bilan_treewiew.delete(children)
def set_bilan_treeview(*args):
    try:
        values = get_bilan(label_date1_bilan.cget("text"), label_date2_bilan.cget("text"))

        for children in bilan_treewiew.get_children():
            bilan_treewiew.delete(children)
        for i, value in enumerate(values):
            tag = "evenrow" if i % 2 == 0 else "oddrow"
            bilan_treewiew.insert("", index=0,  values=list(value.values())[:-1])
    except:
        pass


def set_all_facture_treeview(status_reste_payer=False):
    for children in bilan_treewiew.get_children():
        bilan_treewiew.delete(children)
    values = get_all_database_facture()

    for i, value in enumerate(values):
        tag = "evenrow" if i % 2 == 0 else "oddrow"
        bilan_treewiew.insert("", index=0, values=value, )


#frame_bilan

style_buttons_menu = Style()
style_buttons_menu.configure("success.TButton", font=(font, 14))
button_faire_facture = Button(frame_menu, text="Etablir Facture",
width=12, style="success.TButton",command=show_frame_faire_facture)
button_faire_facture.place(relx=0.01, rely=0.2)

button_menu_bar = Button(root, text="Menu",image=image_menu_bar,
width=10,command=show_acceuil,style="success.TButton",compound="left")
button_menu_bar.place(relx=0.001, rely=0.002)

button_verifier_facture = Button(frame_menu, text="Vérifier Facture",
                                 width=12, command=consulter_facture, style="success.TButton", )
button_verifier_facture.place(relx=0.01, rely=0.33)

button_faire_bilan = Button(frame_menu, text="Faire Bilan", style="success.TButton",
                            width=12, command=faire_bilan)
button_faire_bilan.place(relx=0.01, rely=0.47)

button_accueil = Button(frame_menu, text="Accueil", style="success.TButton",
                        width=12, command=show_acceuil)
button_accueil.place(relx=0.01, rely=0.07)


button_parametres = Button(frame_menu, text="Paramètres", style="success.TButton",
                        width=12, command=show_parametres)
button_parametres.place(relx=0.01, rely=0.6)

string_var_mode_sombre=IntVar(value=0)
Label(frame_menu,text="Mode Sombre",font=(font,12,),).place(relx=0.08,rely=0.9)
mode_sombre_checkbutton=Checkbutton(frame_menu,style="success-round-toggle",text="",
onvalue=1,variable=string_var_mode_sombre,compound="right",command=set_dark_theme,)
mode_sombre_checkbutton.place(rely=0.92,relx=0.715)

#frame_info client

Label(frame_info_client, style="success",text="Informations du client", font=(font, 22, "bold", "italic"), ).place(
relx=0.3,rely=0.01)
nom_client = Entry(frame_info_client, textvariable=list_string_var[0], width=30,
                   font=("Bookman Old Style", 19), justify="center",)
nom_client.place(relx=0.25, rely=0.15)
numero_client = Entry(frame_info_client, textvariable=list_string_var[1], width=30
                      , font=("Bookman Old Style", 19),justify="center",)
numero_client.place(relx=0.25, rely=0.33)

adresse_client = Entry(frame_info_client, width=30,justify="center"
                       , textvariable=list_string_var[2], font=(font, 18))
adresse_client.place(relx=0.25, rely=0.5)

Label(frame_info_client, text="Nom du client:", font=(font, 21, "italic")).place(relx=0.001, rely=0.15)

Label(frame_info_client, text="Téléphone du client:", font=(font, 18, "italic")).place(relx=0.001, rely=0.33)

Label(frame_info_client, text="Adresse du client:", font=(font, 20, "italic")).place(relx=0.001, rely=0.5)
frame_nom_fact_date = Frame(frame_info_client, width=700, height=150)

Label(frame_info_client, text="Nom de la facture:", font=(font, 20, "italic")).place(relx=0.01, rely=0.7)

nom_facture = Entry(frame_info_client, textvariable=list_string_var[3], width=30,
                    font=("Bookman Old Style", 19),justify="center",)
nom_facture.place(relx=0.25, rely=0.7)
string_date_facture=list_string_var[4]
date = DateEntry(frame_info_client, width=10, bootstyle="success",)
date.entry.configure(textvariable=string_date_facture)
date.place(relx=0.87, rely=0.7)

Label(frame_info_client, text="Date:", font=(font, 21, "italic")).place(relx=0.78, rely=0.69)

style_button_suivant = Style()
style_button_suivant.configure("Suivant.success.TButton", font=(font, 16))
button_suivant1 = Button(frame_info_client, style="Suivant.success.TButton",
                         text="Suivant", command=show_frame_remplissage_materiel, )
button_suivant1.place(relx=0.68, rely=0.82)

#frame remplissage_achat_materiel

frame_table = Frame(frame_remplissage_materiel, width=1055, height=5)
frame_table.place(relx=0.003, rely=0.4)
treeview_achat_materiel = ttk.Treeview(frame_table, columns=colonnes_materiel_table, show="headings", height=7)
scrollbar = Scrollbar(frame_table, orient="vertical", command=treeview_achat_materiel.yview)
treeview_achat_materiel.bind("<<TreeviewSelect>>", get_selected_element)
scrollbar.pack(fill="y", side="right")

treeview_achat_materiel.pack(fill="both")
treeview_achat_materiel.configure(yscrollcommand=scrollbar.set)
style = ttk.Style()
style.configure("Treeview.Heading", font=("Bookman Old Style", 15, "bold"),borderwidth=1,)

style.configure("Treeview",
                font=("Helvetica", 15,),rowheight=30 )
for colonne in colonnes_materiel_table:
    treeview_achat_materiel.heading(colonne, text=colonne)
for i, colonne in enumerate(colonnes_materiel_table[1:]):
    treeview_achat_materiel.column(colonne, width=list_width_mat_table[i], anchor="n")
treeview_achat_materiel.column("Références", width=360)
frame_materiel = Frame(frame_remplissage_materiel, width=942, height=190)
frame_materiel.place(relx=0.01, rely=0.01)
stringVar_list = [StringVar(frame_materiel) for _ in range(4)]

materiel_number_label = Label(frame_remplissage_materiel, font=(font, 18, "bold", "underline"), text="")
materiel_number_label.place(relx=0.38, rely=0)
Label(frame_materiel, text="Références:", font=(font, 18,)).place(relx=0, rely=0.2)
nom_materiel = Entry(frame_materiel,justify="center",
                textvariable=stringVar_list[0], width=32, font=(font, 17, "italic"))
nom_materiel.place(relx=0.158, rely=0.2)
Label(frame_materiel, text="Unité:", font=(font, 20)).place(relx=0.7, rely=0.2)
string_var_unite_materiel=StringVar(value="U")
Unite = Entry(frame_materiel, textvariable=stringVar_list[1],justify="center",
              width=7, font=(font, 16))
Unite.place(relx=0.791, rely=0.205)
string_var_quantie_materiel=StringVar()
Label(frame_materiel, text="Quantité:", font=(font, 15)).place(relx=0, rely=0.7)
Quantite = Entry(frame_materiel, textvariable=stringVar_list[2], width=7, font=(font, 15,),
                 justify="center",)
Quantite.place(relx=0.102, rely=0.6901)
Label(frame_materiel, text="Prix Unitaire:", font=(font, 18)).place(relx=0.23, rely=0.7)
prix_unitaire = Entry(frame_materiel, width=10, textvariable=stringVar_list[3],
                    justify="center",font=(font, 16,))
prix_unitaire.place(relx=0.4, rely=0.7)

string_var_total = StringVar(frame_materiel, value="")
Label(frame_materiel, text="Prix Total:", font=(font, 18)).place(relx=0.58, rely=0.7)
prix_Total = Entry(frame_materiel, textvariable=string_var_total, font=(font, 18,),
                   justify="center",width=12)
prix_Total.place(relx=0.715, rely=0.69)
frame_list_button = Frame(frame_remplissage_materiel, width=150, relief="raised", height=170,
                          )
style_list_button_remplissage = Style()
style_list_button_remplissage.configure('Custom3.TButton', font=(font, 16))
frame_list_button.place(relx=0.85, rely=0.01)
button_ajouter_materiel = Button(frame_list_button, style="Custom3.success.TButton",
                                 width=9, text="Ajouter", command=ajouter_materiel, )
button_ajouter_materiel.place(relx=0.05, rely=0.72)

button_supprimer_materiel = Button(frame_list_button, style="Custom3.success.TButton",
                    text="Supprimer", command=supprimer_materiel, width=9, )
button_supprimer_materiel.place(relx=0.055, rely=0.39)
button_modifier_materiel = Button(frame_list_button, style="Custom3.success.TButton",
    width=9, text="Modifier", command=modifier_materiel, )
button_modifier_materiel.place(relx=0.05, rely=0.1)

button_suivant2 = Button(frame_remplissage_materiel,
width=10, text="Suivant", command=show_frame_last_part, style="Suivant.success.TButton")
button_suivant2.place(relx=0.5, rely=0.9)

button_retour1 = Button(frame_remplissage_materiel,
width=10, text="Retour", command=show_frame_faire_facture, style="Suivant.success.TButton")
button_retour1.place(relx=0.2, rely=0.9)

frame_total_achat_materiel = Frame(frame_remplissage_materiel, relief="raised", width=220, height=40)
frame_total_achat_materiel.place(relx=0.773, rely=0.84)

montant_total_materiel_label1 = Label(frame_total_achat_materiel, text="", justify="center",
                                      font=("Bookman Old Style", 20, "bold"))
montant_total_materiel_label1.place(relx=0.02, rely=0.018)
Label(frame_remplissage_materiel, text="Total:", font=(font, 21, "bold", "italic")).place(relx=0.67, rely=0.84)


#frame_last_part

string_var_rest = StringVar()
Label(frame_last_part, text="Total Achat Matériel:",
      font=(font, 19, "italic")).place(relx=0.25, rely=0.04)

frame_total_achat_materiel2 = Frame(frame_last_part, relief="raised", height=43, width=250, )
frame_total_achat_materiel2.place(relx=0.503, rely=0.04)

montant_total_materiel_label = Label(frame_total_achat_materiel2, text="",font=("Bookman Old Style", 20, "bold"))
montant_total_materiel_label.place(relx=0.05, rely=0.05)

main_oeuvre_descipt = Entry(frame_last_part, width=30,justify="center",
        textvariable=list_string_var[5], font=("Bookman Old Style", 17))
main_oeuvre_descipt.place(relx=0.43, rely=0.2)

Label(frame_last_part, text="Montant Main d'œuvre:", font=(font, 20, "italic")).place(relx=0.001,rely=0.39)

main_oeuvre = Entry(frame_last_part, width=13,textvariable=list_string_var[6]
                    , justify="center",font=("Bookman Old Style", 16))
main_oeuvre.place(relx=0.32, rely=0.39)

avance_entry = Entry(frame_last_part, width=13, justify="center",textvariable=list_string_var[7]
                     , font=("Bookman Old Style", 17))
avance_entry.place(relx=0.3, rely=0.593)

reste_payer = Entry(frame_last_part, textvariable=string_var_rest, width=13,
                    font=("Bookman Old Style", 19), justify="center")
reste_payer.place(relx=0.74, rely=0.593)

frame_total = Frame(frame_last_part, width=250, height=42,relief="raised")
frame_total.place(relx=0.71, rely=0.377)
Label(frame_last_part, text="Total:", font=(font, 21, "bold", "italic")).place(relx=0.612,rely=0.375)
button_valider = Button(frame_last_part, style="Suivant.success.TButton",
                        text="Suivant", command=afficher_resume_facture, width=11, )
button_valider.place(relx=0.7, rely=0.78)

button_retour1 = Button(frame_last_part, style="Suivant.success.TButton",
text="Retour", command=retour_last_part_to_remplissage_mat, width=10, )
button_retour1.place(relx=0.2, rely=0.78)

Label(frame_last_part, text="Descriptions de la main d'œuvre:",
      font=(font, 20, "italic")).place(relx=0.001, rely=0.2)

Label(frame_last_part, text=" Montant Avance reçu:", font=(font, 20, "italic")).place(relx=0.005,rely=0.59)
Label(frame_last_part, text="Reste à payer:", font=(font, 19, "italic")).place(relx=0.56, rely=0.593)
montant_total_label = Label(frame_total, text="", font=(font, 20, "bold"))
montant_total_label.place(relx=0.08, rely=0.1)
directory_to_save_facture = Label(frame_last_part, text="")


def set_date1_bilan(*args):
    calendar = Querybox()
    dat1 = calendar.get_date()

    label_date1_bilan.configure(text=str(dat1).replace('-',"/"))

    string_var_date1_button.set(value=change_date_format(str(dat1).replace('-',"/")))

def set_date2_bilan(*args):
    calendar = Querybox()
    dat2 = calendar.get_date()
    label_date2_bilan.configure(text=str(dat2).replace('-', "/"))
    string_var_date2_button.set(value=change_date_format(str(dat2).replace('-',"/")))


frame_treeview_bilan = Frame(frame_bilan, width=800, height=300)
frame_treeview_bilan.place(relx=0.025, rely=0.27)
Label(frame_bilan, text="Date Début:", font=(font, 18, "italic")).place(relx=0.002, rely=0.1)
string_var_date1_button=StringVar()
button_date1=Button(frame_bilan,style="success",command=set_date1_bilan,text="Choisir date début")
button_date1.place(relx=0.14,rely=0.1)

string_var_date2_button=StringVar()

string_var_date1_button.trace_add("write",refresh_bilan_treeview)
button_date2=Button(frame_bilan,style="success",command=set_date2_bilan,text="Choisir date fin")
button_date2.place(relx=0.65,rely=0.1)

string_var_date2_button.trace_add("write",refresh_bilan_treeview)

label_date1_bilan=Label(frame_bilan,text=get_date(),style="info",font=(font,19))
label_date1_bilan.place(relx=0.35,rely=0.1)

label_date2_bilan=Label(frame_bilan,text=get_date(),style="info",font=(font,19))
label_date2_bilan.place(relx=0.83,rely=0.1)

Label(frame_bilan, text="Date Fin:", font=(font, 18, "italic")).place(relx=0.52, rely=0.1)

exporter_bilan_path = Label(frame_bilan, text='')
Label(frame_bilan, text="Sélectionnez toutes les Factures",font=(font,17)).place(relx=0.05, rely=0.2)
stringvar_bilan_checkbox=IntVar(value=0)
checkbox_bilan = Checkbutton(frame_bilan, text="",variable=stringvar_bilan_checkbox,
    style="success-round-toggle", command=call_checbox_bilan_fonction,onvalue=1)
checkbox_bilan.place(relx=0.41, rely=0.211)



style_button_exporter_bilan = Style()
style_button_exporter_bilan.configure("Custom.success.TButton", font=(font, 14))
faire_bilan_button = Button(frame_bilan,
                            text="Exporter le bilan en fichier PDF", command=exporter_bilan,
                            width=25, style="Custom.success.TButton")
faire_bilan_button.place(relx=0.32, rely=0.83)

bilan_treewiew = ttk.Treeview(frame_treeview_bilan, height=9, columns=colonne_bilan,
                              show="headings", )

bilan_treewiew.tag_configure("oddrow", background="lightblue")
bilan_treewiew.tag_configure("evenrow", background="white")
scrollbar_treeview_bilan = Scrollbar(frame_treeview_bilan, command=bilan_treewiew.yview
                                     , orient="vertical")
scrollbar_treeview_bilan.pack(fill="y", side="right")
bilan_treewiew.pack(fill="x")
bilan_treewiew.configure(yscrollcommand=scrollbar_treeview_bilan.set)

list_witdh_bilan_treview = [200, 155, 120, 110, 154, 130, 130]
for index, colonne in enumerate(colonne_bilan):
    bilan_treewiew.heading(column=colonne, text=colonne)
    bilan_treewiew.column(colonne, width=list_witdh_bilan_treview[index],
                          anchor=list_anchor_coloums[index])

Label(frame_bilan, text="Faire le bilan d'une période donnée!",
      font=(font, 20, "italic", "bold")).place(
    relx=0.2, rely=0.01)

#consulter facture

def set_facture_in_treewiew(*args):
    for element in list_facture_table.get_children():
        list_facture_table.delete(element)
    Date = date_consulter_fac.entry.get()
    list_factures = consulter_facture_with_date(Date)

    for ind, facture in enumerate(list_factures):
        tag = "evenrow" if ind % 2 == 0 else "oddrow"
        list_facture_table.insert("", index=0, values=facture)


date_consulter_fac = DateEntry(frame_consulter_facture, width=12,bootstyle="success")
date_consulter_fac.place(relx=0.09, rely=0.1)
Label(frame_consulter_facture, text="Date:", font=(font, 20, "italic")).place(relx=0.01, rely=0.1)
string_var_date_consul=StringVar(value=get_date())

def testsss(*args):
    string_var_date_consul.set(date_consulter_fac.entry.get())
    set_facture_in_treewiew()
string_var_date_consul.trace_add("write",testsss)
date_consulter_fac.entry.configure(textvariable=string_var_date_consul)
frame_table_facture = Frame(frame_consulter_facture, width=1000, height=300, )
frame_table_facture.place(relx=0.008, rely=0.32)

tree_frame = Frame(frame_table_facture, width=1040, height=300)
tree_frame.pack()
list_facture_table = ttk.Treeview(tree_frame, height=10, columns=facture_table_colonnes,
                                  show="headings", )
list_facture_table.pack(expand=True, side="left")

scrollbar_treeview_consult = Scrollbar(tree_frame, command=list_facture_table.yview
                                       , orient="vertical")
scrollbar_treeview_consult.pack(side="right", fill="y")

list_facture_table.configure(yscrollcommand=scrollbar_treeview_consult.set)

for indexe, colonne in enumerate(facture_table_colonnes):
    list_facture_table.heading(column=colonne, text=colonne)
    list_facture_table.column(colonne, width=list_colonnes_width[indexe], anchor="center")
list_facture_table.tag_configure("oddrow", background="lightblue")
list_facture_table.tag_configure("evenrow", background="white")
Label(frame_consulter_facture, text="Vérifier une facture enregistrée ", font=(font, 20, "bold", "italic")).place(
    relx=0.22, rely=0.001)

Label(frame_consulter_facture, text="Entrer N° Facture:", font=(font, 19, "italic")).place(relx=0.22, rely=0.1)
numero_facture_entry = Entry(frame_consulter_facture, width=17,
                             textvariable=StringVar(frame_consulter_facture, value="N°FP00"),
                             font=("Bookman Old Style", 14))
numero_facture_entry.place(relx=0.44, rely=0.1)


def get_selected_treeview_element(*args):
    return list_facture_table.selection()


def set_frame_list_button():
    selection = ""
    try:
        selection = get_selected_element()[0]
    except:
        pass
    if selection:
        button_supprimer_materiel.place(relx=0.1, rely=0.4)
        button_modifier_materiel.place(relx=0.1, rely=0.1)
    else:
        button_supprimer_materiel.place(relx=1, rely=0.5)
        button_modifier_materiel.place(relx=1, rely=0.1)

    root.after(100, set_frame_list_button)




def get_selected_facture(*args):
    return list_facture_table.selection()


def get_exporter_path():
    path = filedialog.askdirectory()
    label_exporter_fichier.configure(text=path)
    pass



frame_modifier_reste = Frame(frame_modifier_reste_payer, width=700,height=400,relief="raised")
frame_modifier_reste.place(relx=0.1,rely=0.1)
frame_label_reste1 = Frame(frame_modifier_reste, width=230,height=40,relief="raised" )
frame_label_reste1.place(relx=0.615, rely=0.2)
database_reste = Label(frame_label_reste1, text="25 000 000", font=(font, 20, "bold"))
database_reste.place(relx=0.1, rely=0.05)

frame_label_reste = Frame(frame_modifier_reste, width=200,height=42,relief="raised" )
frame_label_reste.place(relx=0.58, rely=0.68)
Resultat_reste = Label(frame_label_reste, text="1 500 600", font=(font, 20, "bold"))
Resultat_reste.place(relx=0.1, rely=0.1)

modifier_reste_stringvar = StringVar(frame_modifier_reste)
entry_Regler = Entry(frame_modifier_reste, textvariable=modifier_reste_stringvar,
                     width=14, font=(font, 18),justify="center")
entry_Regler.place(relx=0.54, rely=0.47)

entry_Regler.bind("<Key>", set_modifier_reste)
Label(frame_modifier_reste, text="Enter le montant à régler:",
      font=(font, 18, "italic")).place(relx=0.1, rely=0.47)

Label(frame_modifier_reste, text="Régler le Reste à Payer",
      font=(font, 23, "italic", 'bold')).place(relx=0.3, rely=0.01)

checkbox = Checkbutton(frame_modifier_reste,style="success-round-toggle",
                       onvalue=1, command=fill_entry_regler, text="")
Label(frame_modifier_reste, text="Tout", font=(font, 17, "italic")).place(relx=0.61, rely=0.352)
checkbox.place(relx=0.7, rely=0.36)
Label(frame_modifier_reste, text="Voici ce qui reste à payer:",
      font=(font, 20, "italic")).place(relx=0.1, rely=0.68)
Label(frame_modifier_reste, text="Voici ce qui restait à payer:",
      font=(font, 20, "italic")).place(relx=0.1, rely=0.2)

valider_reste_payer = Button(frame_modifier_reste,style="Suivant.success.TButton",
                    text="Valider", command=modifier_reste_seul, width=9, )
valider_reste_payer.place(relx=0.56, rely=0.86)

button_retour3 = Button(frame_modifier_reste,style="Suivant.success.TButton",
                        text="Retour", command=consulter_facture, width=6, )
button_retour3.place(relx=0.1, rely=0.86)

frame_list_button_consult = Frame(frame_consulter_facture, width=212, relief='raised',
                                  height=178)
frame_list_button_consult.place(relx=0.82, rely=0.01)
label_exporter_fichier = Label(frame_consulter_facture, text="", )
style_buttons_cherche = Style()
style_buttons_cherche.configure("Custom1.success.TButton", font=(font, 15))
button_rechercher = Button(frame_consulter_facture, text="Chercher Facture",
                           command=chercher_facture, width=15, style="Custom1.success.TButton")
button_rechercher.place(relx=0.4, rely=0.22)

button_show_all_facture = Button(frame_consulter_facture,
                                 text="Voir toutes les factures", command=show_all_facture,
                                 width=19, style="Custom1.success.TButton")
button_show_all_facture.place(relx=0.1, rely=0.22)

list_facture_table.bind("<<TreeviewSelect>>", get_selected_facture)
style_list_buttons_cons = Style()
style_list_buttons_cons.configure("Custom2.success.TButton", font=(font, 13))
button_supprimer_consult = Button(frame_list_button_consult,width=17,
text="Supprimer Facture", command=supprimer_fichier, style="Custom2.success.TButton")

numero_facture_entry.bind("<Return>", chercher_facture)

button_modifier_consulter = Button(frame_list_button_consult,
text="Modifier Facture", command=modifier_completement_facture,
                                   width=17, style="Custom2.success.TButton")

button_modifier_reste_consulter = Button(frame_list_button_consult,width=17,
text="Régler reste à payer", command=modifier_reste,style="Custom2.success.TButton",)

button_exporter_fact = Button(frame_list_button_consult,width=17,
text="Exporter Facture", command=exporter_fichier, style="Custom2.success.TButton",)

button_exporter_fact.place(relx=0.05, rely=0.79)
button_supprimer_consult.place(relx=0.05, rely=0.525)
button_modifier_consulter.place(relx=0.05, rely=0.28)
button_modifier_reste_consulter.place(relx=0.05, rely=0.05)




def set_time():
    Time = strftime("%H:%M:%S").strip()
    date = strftime("%d/%m/%Y")
    label_heure.configure(text=Time + "\n" + date)
    root.after(1000, set_time)


Label(frame_page_accueil, text="bonjour", image=image_faire_facture).place(relx=0.05, rely=0.27)
Label(frame_page_accueil, text="", image=image_consult_fact).place(relx=0.39, rely=0.27)
Label(frame_page_accueil, text="", image=image_faire_bilan).place(relx=0.72, rely=0.282)

Label(frame_page_accueil, text="Bienvenue sur le logiciel de gestion de dévis de MANTECH"
      , font=(font, 22, "bold", "underline", "italic", "roman"),style="success" ).place(relx=0.1, rely=0.01)

style_button_accueil=Style()
style_button_accueil.configure("Accueil.success.TButton",font=(font,17))

button_faire_facture = Button(frame_page_accueil, text="Etablir Facture",
                              width=15,style="Accueil.success.TButton",
                              command=show_frame_faire_facture)
button_faire_facture.place(relx=0.08, rely=0.88)

button_verifier_facture = Button(frame_page_accueil, text="Vérifier Facture",
        width=14, command=consulter_facture,style="Accueil.success.TButton",)
button_verifier_facture.place(relx=0.44, rely=0.88)

button_faire_bilan = Button(frame_page_accueil, text="Faire Bilan",
            width=17, command=faire_bilan,style="Accueil.success.TButton",)
button_faire_bilan.place(relx=0.72, rely=0.88)


label_heure = Label(frame_page_accueil, text="",style="primary", font=(font, 23,"bold"),
                    )
label_heure.place(relx=0.8, rely=0.08)




def reset_database_front():
    status=messagebox.okcancel(title="status de la suppression",
    message="Voulez-vous supprimer \ntoutes les données?",position=(650,156))
    if status=="OK":
        reset_database()
        messagebox.show_info(title="Status de  la suppression des données",
                             message="Données supprimées avec succès",position=(650,156))

def show_developpeur_info():
    messagebox.show_info(message=""" Nom: ZONGO Edouard 
        Téléphone: +226 66 16 90 83 / 78 74 35 89
        Adresse: Ouagadougou 
        Adresse Email:zongoedouard49@gmail.com
        Pour tout besoin  ou d'amélioration du logiciel vous pouvez nous contacter 
        """, title="Informations du développeur", position=(520, 250))



frame_parametre=Frame(frame_parametres,width=560,height=300,relief="raised")
frame_parametre.place(relx=0.25,rely=0.1)

Label(frame_parametre,text="Paramètres",style="success",
    font=(font,25,"bold",'italic',"underline")).place(relx=0.32,rely=0.05)
Label(frame_parametre,text="""En appuyant sur effacer toutes les 
données , toutes les factures enregistrées\n seront définitivement supprimées"""
      ,
    font=(font,18,'italic')).place(relx=0.1,rely=0.3)

Style().configure("Parametre.danger.TButton",font=(font,16))
button_reset=Button(frame_parametre,text="Effacer toutes les données",
                    style="Parametre.danger.TButton",command=reset_database_front)
button_reset.place(relx=0.26,rely=0.74)
button_info_developpeur=Button(frame_parametres,text="A Propos",style="Dev.info.TButton",
                               command=show_developpeur_info)
button_info_developpeur.place(relx=0.86,rely=0.92)




root.after(100, set_montant_total_facture)
root.after(100, set_montant_restant)
root.after(100, show_montant_total_materiel)
root.after(100, set_frame_list_button)
root.after(100, set_modifier_reste)
root.after(100, refresh_materiel_number)
frame_remplissage_materiel.after(100, set_montant_total_materiel)
#show_widget(frame_page_accueil)
root.after(100, pack_list_consulter_button_mod_supp_exp)

root.after(1000, set_time)

root.mainloop()
