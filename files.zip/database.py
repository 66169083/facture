import json

tem={"client":"Zongoœü,ê,ôûâèèàç","Num_Facture":"N°FP001/11/2024","Materiel":"1 500 000 000",
"Main_oeuvre":"150 000 000","Avance":"150 000 000","Reste":"150 000 000","montant_ht":"150 000 000"}

"""item={"client":"Zongoœü,ê,ôûâèèàç","Num_Facture":"N°FP001/11/2024","Materiel":"1 500 000 000",
"Main_oeuvre":"150 000 000","Avance":"150 000 000","Reste":"0","montant_ht":"150 000 000"}"""

item = {"reference": "cameras", "qte": "1", "unite": "U", "prix_unitaire": "50000", "montant_ht": "100000"}

items=[]
for i in range(80):
    items.append(item)

items=json.dumps(items)
main_oeuvre_des="Main oeuvre Frais de formationFrais de formationFrais de formation"
main_oeuvre_montant="500000"
reste="150 000"
avance="250 000"
total="1 000 000"
achat="600 000"
nom_facture="Frais de formation"
numero_facture="N°FP002_11_2024"
nom_client="Zongo Edouard "
numero_client="+226 66169083"
address="Ouagadougou"
date="26/11/2024"
""""facture=Facture(numero_facture,nom_client,numero_client,address,nom_facture,date,
                items,achat,main_oeuvre_montant,main_oeuvre_des,total,avance,reste,
                "",)
facture.produire_facture_achat_materiel_unique()"""


from logique import Facture,dumps
from sqlite3 import connect



def get_database_data(id_facture):
    connexion = connect("database.db")
    sql = f"""SELECT * from DATA where Numero_facture="{id_facture}" """
    data = connexion.execute(sql).fetchone()[:-3]
    return data


if 0 == 0:
    numero = "N° FP002_10_2024"
    client = "Ouedraogo"
    tel = "+226 25 30 75 30"
    adresse = "Bobo Dioulasso"

    # Liste des articles
    item = [
        {"reference": "convertisseur", 'qte': "1", 'unite': 'U', 'prix_unitaire': "16000", 'montant_ht': "1600000"}]
    items = []
    for i in range(18):
        for value in item:
            items.append(value)

    items = dumps(items)

    # Totaux
    total_achat = "0"
    total_avance = "185 000"
    reste_a_payer = "489 000"
    total_ht = "815 000"
    main_oeuvre = "45 000"
    main_oeuvre_nom = ""

    facture_name = "Fourniture et installation d'un système de vidéosurveillance IP dans les locaux de SOGEPER"
    # Création du PDF

pdf = Facture(total=total_ht, total_achat=total_achat, reste=reste_a_payer,
                  avance=total_avance, montant_main_oeuvre=main_oeuvre,
                  main_oeuvre_nom=main_oeuvre_nom,
                  client=client, tel=tel, facture_name=facture_name,
                  items=items, numero_facture=numero, date="10/11/2024",
                  addresse=adresse, directory_path="E:/pycharmProjects/gestion_devis")
pdf.produire_facture()
def update_taxe_status(status):
    connexion = connect("database.db")
    connexion.execute(f"Update Taxe set status={status}")
    connexion.commit()
    connexion.close()
def get_taxe_status():
    connexion = connect("database.db")
    return connexion.execute("select status from Taxe").fetchone()[0]



